﻿using System.Windows.Forms;

namespace clientCs
{
    public partial class MainWindow : Form
    {
        private TeledonClientController Controller;
        public MainWindow(TeledonClientController controller)
        {
            InitializeComponent();
            this.Controller = controller;
        }
    }
}