﻿using teledonCS.model;

namespace teledonCS.repository
{
    public interface IDonationRepository:ICrudRepository<int,Donation>
    {
        
    }
}