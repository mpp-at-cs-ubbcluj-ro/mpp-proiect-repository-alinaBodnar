﻿namespace SharedProject1
{
    class Class1
    {
    }
}